package org.example;

public interface Colorable {
    public boolean howToColor();
}
