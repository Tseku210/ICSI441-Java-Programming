package org.example;

import java.io.File;
import java.util.Random;

public class Main {
    // sanamsarguigeer 100 buhel too uusgej tedniig faild bichne (binary file). Ene fail dahi tegsh toonuudiig niit toonii heden huviig ezleh ve?
    public static void main(String[] args) {
        File file = new File("output.txt");

        Random rand = new Random();
        for (int i = 0; i < 100; i++) {

        }
    }
}